﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project2_rp
{
    class String
    {
        String namaOrtu, alamat, jenis, usia, namaPasien;
    }
}
