# Sistem-Diagnosis-Autisme-pada-Anak
Sistem Diagnosis Autisme pada Anak dengan metode naive bayes dan C#
